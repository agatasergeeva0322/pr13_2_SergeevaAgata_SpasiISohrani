﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Обобщенные_коллекции
{
    class Student
    {
        private string name;
        private string lastname;
        private int number;
        public Student(string name, string lastname, int number)
        {
            this.name = name;
            this.lastname = lastname;
            this.number = number;
        }
        public void set_name(string n)
        {
            this.name = n;
        }
        public string get_name()
        {
            return this.name;
        }
        public void set_lastname(string n)
        {
            this.lastname = n;
        }
        public string get_lastname()
        {
            return this.lastname;
        }
        public void set_number(int n)
        {
            this.number = n;
        }
        public int get_number()
        {
            return this.number;
        }
    }
}
